import { Component } from '@angular/core';

@Component({
  selector: 'app-my-component',
  standalone: true,
  imports: [],
  templateUrl: './my-component.component.html',
  styleUrl: './my-component.component.css',
})
export class MyComponentComponent {}

// above is an example of standalone component , it doesnt get registered in the
// declaration section of any Angular module. since it is not registered depends on an
// Angular module for registeration -- hence referred as 'Standalone'.

// How to make it standalone?
// We make a component standalong by adding a property   'standalone: true'
// as seen in above component decorator

// How to preload the standalone component?
// we will import & preload this component class in another Angular module 'AppModule'
// check the app.module.ts you will find the below lines of code.

//import { MyComponentComponent } from './my-component/my-component.component';

// imports: [BrowserModule, FormsModule, MyComponentComponent], // preloading angular modules -- blocking script --- dependency modules -- helper or utility modules -- wider scopes

// How to use the standalone component?
// Just like any other component - load it via another components template
// as seen in app.component.html
//<app-my-component></app-my-component>

// Making components standalone make them not bound to any module, hence
// reusing them in another project is fairly easy and does not require
// to load any Angular module and its registered entities. thus making the
//new angular project lighter. This feature was introduced in Angular 17
