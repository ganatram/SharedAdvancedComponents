Standalone components:

check file my-component.component.ts

// above is an example of standalone component , it doesnt get registered in the
// declaration section of any Angular module. since it is not registered depends on an
// Angular module for registeration -- hence referred as 'Standalone'.

// How to make it standalone?
// We make a component standalong by adding a property   'standalone: true'
// as seen in above component decorator

// How to preload the standalone component?
// we will import & preload this component class in another Angular module 'AppModule'
// check the app.module.ts you will find the below lines of code.

//import { MyComponentComponent } from './my-component/my-component.component';

// imports: [BrowserModule, FormsModule, MyComponentComponent], // preloading angular modules -- blocking script --- dependency modules -- helper or utility modules -- wider scopes

// How to use the standalone component?
// Just like any other component - load it via another components template
// as seen in app.component.html
//<app-my-component></app-my-component>

// Making components standalone make them not bound to any module, hence
// reusing them in another project is fairly easy and does not require
// to load any Angular module and its registered entities. thus making the
//new angular project lighter. This feature was introduced in Angular 17






Signals:
   check file app.component.ts and app.component.html

   import {signal} from '@angular/core';

  //signal - set method - creates and publishes the signal
  firstname = signal('steve');
  lastname = signal('souders');


  // to subscribe to signal check app.component.html

  <!-- when signal is subscrined in template it should suffix with () indicating a
get() method as below: -->

<div>{{ firstname() }}</div>
<div>{{ lastname() }}</div>
<div>{{ fullname() }}</div>

Ideally signals are better than zone regions who maintain templates ,
given the fact that once a 'certain signal' is published it doent require
to check all property bindings in template (such as {{}},[],*directive)
like how  a Zone region does,
rather the corresponding signal in template would be quickly recollected & updated.

