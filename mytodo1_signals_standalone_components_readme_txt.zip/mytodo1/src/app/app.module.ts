import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { MyComponentComponent } from './my-component/my-component.component';

@NgModule({
  declarations: [AppComponent], // register components,directives & pipes
  imports: [BrowserModule, FormsModule, MyComponentComponent], // preloading angular modules -- blocking script --- dependency modules -- helper or utility modules -- wider scopes
  providers: [], // register & launch services -- injectable
  bootstrap: [AppComponent], // launch a component
})
export class AppModule {} // registry & launcher --- for custom angular entities
