import { Model, TodoItem } from './model';
import { Component, computed, signal } from '@angular/core';

@Component({
  selector: 'app',
  templateUrl: 'app.component.html',
})
export class AppComponent {
  //signal - set method
  firstname = signal('steve');
  lastname = signal('souders');

  //computed signals are derived by using existing signals as below:
  fullname = computed(() => `${this.firstname()} ${this.lastname()}`);

  model = new Model();

  getName() {
    return this.model.user;
  }

  getTodoItems() {
    return this.model.items.filter((item) => !item.done);
  }

  addItem(newItem: any) {
    //console.log(newItem);

    if (newItem != '') {
      this.model.items.push(new TodoItem(newItem, false));
    }
  }
}
function lastname() {
  throw new Error('Function not implemented.');
}
